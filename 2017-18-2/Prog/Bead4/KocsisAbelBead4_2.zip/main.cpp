#include <iostream>
#include <vector>
#include "menu.h"

using namespace std;

int main(){
    cout << "Dinamikus tomb" << endl;
    Menu Teszt;
    Teszt.Run();
    return 0;
}