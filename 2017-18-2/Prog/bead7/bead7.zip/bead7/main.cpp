#include <iostream>
#include "enor.h"

using namespace std;

int main(){
    Beolv o ("ast.txt");
    o.first();
    //cout << o.end();
    string azonelozo;
    bool l = true;
    Aster atm;
    atm = o.current();
    azonelozo = atm.azonosíto();
    while (!o.end()){
        atm = o.current();
        if (azonelozo == atm.azonosíto()){
            if (atm.tav() >= 10000)
                l = false;
        }
        else{
            if (l){
                cout << azonelozo << endl;
            }
            azonelozo = atm.azonosíto();
            if (atm.tav() >= 10000)
                 l = false;
            else
                l = true;
        }
        o.next();
    }
    if (l){
                cout << azonelozo << endl;
            }
}